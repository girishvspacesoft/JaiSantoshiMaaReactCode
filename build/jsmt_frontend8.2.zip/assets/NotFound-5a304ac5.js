import{a as t}from"./react-69b9bddd.js";import"./@babel-5e587562.js";const r=()=>t.createElement("p",null,"Not found");export{r as default};
