import{j as l}from"./react-69b9bddd.js";import{G as r,n as y}from"./@emotion-17579717.js";function i(s){return s==null||Object.keys(s).length===0}function f(s){const{styles:t,defaultTheme:e={}}=s,o=typeof t=="function"?n=>t(i(n)?e:n):t;return l.jsx(r,{styles:o})}/**
 * @mui/styled-engine v5.14.11
 *
 * @license MIT
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */function u(s,t){return y(s,t)}const _=(s,t)=>{Array.isArray(s.__emotion_styles)&&(s.__emotion_styles=t(s.__emotion_styles))};export{f as G,_ as i,u as s};
