import{a as t}from"./react-69b9bddd.js";import"./@babel-5e587562.js";const o=()=>t.createElement("h1",null,"Cash Memo List");export{o as default};
